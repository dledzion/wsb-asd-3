﻿using System;

namespace wsb_asd_3
{
    public class TabGenerator
    {
        public static int[] Constant(int length)
        {
            var table = new int[length];
            for (var i = 0; i < length; i++)
            {
                table[i] = 1;
            }

            return table;
        }

        public static int[] Growing(int length)
        {
            var table = new int[length];
            for (var i = 0; i < length; i++)
            {
                table[i] = i;
            }

            return table;
        }

        public static int[] Random(int length)
        {
            var r = new Random(Guid.NewGuid().GetHashCode());
            var table = new int[length];

            for (var i = 0; i < length; i++)
            {
                table[i] = r.Next(1, 200000);
            }

            return table;
        }

        public static int[] Decreasing(int length)
        {
            var table = new int[length];

            for (var i = length; i >= 0; i--)
            {
                table[i] = i;
            }

            return table;
        }

        public static int[] VShaped(int length)
        {
            var table = new int[length];

            for (var i = 0; i < length / 2; i++)
            {
                table[i] = i;
            }

            for (var i = length / 2; i >= 0; i--)
            {
                table[i] = i;
            }

            return table;
        }
    }
}