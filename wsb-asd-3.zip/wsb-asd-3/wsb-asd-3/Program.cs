﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using wsb_asd_3.Algorithms;

namespace wsb_asd_3
{
    class Program
    {
        static void Main(string[] args)
        {
            var algorithms = new List<ISortAlgorithm>
            {
                new CocktailSort(),
                new HeapSort(),
                new InsertionSort(),
                new SelectionSort(),
                new QuickSortIterative(),
                new QuickSortMiddle(),
                new QuickSortRandom(),
                new QuickSortRight()
            };

            foreach (var algorithm in algorithms)
            {
                TestAlgorithm(algorithm);
            }

            Console.ReadLine();
        }

        static void TestAlgorithm(ISortAlgorithm sortAlgorithm)
        {
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine($"Testing algorithm: {sortAlgorithm.GetType().Name}");

            Console.WriteLine("\n> V-shaped data:");
            TestOnSet(sortAlgorithm, TabGenerator.VShaped);

            Console.WriteLine("\n> Growing data:");
            TestOnSet(sortAlgorithm, TabGenerator.Growing);

            Console.WriteLine("\n> Decreasing data:");
            TestOnSet(sortAlgorithm, TabGenerator.Decreasing);

            Console.WriteLine("\n> Constant data:");
            TestOnSet(sortAlgorithm, TabGenerator.Constant);

            Console.WriteLine("\n> Random data:");
            TestOnSet(sortAlgorithm, TabGenerator.Random);
        }

        static void TestOnSet(ISortAlgorithm sortAlgorithm, Func<int, int[]> tabGenFunc)
        {
            int ordinary = 0;
            for (int i = 50000; i <= 200000; i += 5000)
            {
                ordinary++;
                int[] table = TabGenerator.Growing(i);
                var watch = Stopwatch.StartNew();

                sortAlgorithm.Sort(table);

                watch.Stop();
                var elapsedSeconds = watch.Elapsed.TotalSeconds;
                Console.WriteLine(ordinary + "\t" + table.Length + "\t" + elapsedSeconds);
            }
        }
    }
}