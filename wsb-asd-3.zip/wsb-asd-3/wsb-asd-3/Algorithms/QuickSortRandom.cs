﻿using System;

namespace wsb_asd_3.Algorithms
{
    public class QuickSortRandom : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            Sort(table, 0, table.Length - 1);
        }

        private void Sort(int[] table, int left, int right)
        {
            var r = new Random(Guid.NewGuid().GetHashCode());
            int i, j, x;
            i = left;
            j = right;
            x = table[r.Next(i, j)];

            do
            {
                while (table[i] < x) i++;
                while (x < table[j]) j--;
                if (i <= j)
                {
                    int buf = table[i];
                    table[i] = table[j];
                    table[j] = buf;
                    i++;
                    j--;
                }
            } while (i <= j);

            if (left < j) Sort(table, left, j);
            if (i < right) Sort(table, i, right);
        }
    }
}