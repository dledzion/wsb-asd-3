﻿namespace wsb_asd_3.Algorithms
{
    public class QuickSortIterative : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            int i, j, l, p, sp;

            int[] leftStack = new int[table.Length],
                rightStack = new int[table.Length];

            sp = 0;
            leftStack[sp] = 0;
            rightStack[sp] = table.Length - 1;

            do
            {
                l = leftStack[sp];
                p = rightStack[sp];
                sp--;
                
                do
                {
                    int x;
                    i = l;
                    j = p;
                    x = table[(l + p) / 2];

                    do
                    {
                        while (table[i] < x) i++;
                        while (x < table[j]) j--;

                        if (i <= j)
                        {

                            int buf = table[i];
                            table[i] = table[j];
                            table[j] = buf;
                            i++;
                            j--;

                        }

                    } while (i <= j);
                    
                    if (i < p)
                    {
                        sp++;
                        leftStack[sp] = i;
                        rightStack[sp] = p;
                    }

                    p = j;

                } while (l < p);

            } while (sp >= 0);
        }
    }
}