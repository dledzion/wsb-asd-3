﻿namespace wsb_asd_3.Algorithms
{
    public interface ISortAlgorithm
    {
        void Sort(int[] table);
    }
}