﻿namespace wsb_asd_3.Algorithms
{
    public class InsertionSort : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            for (uint i = 1; i < table.Length; i++)
            {
                var j = i;
                var temp = table[j];

                while ((j > 0) && (table[j - 1] > temp))
                {
                    table[j] = table[j - 1];
                    j--;
                }

                table[j] = temp;
            }
        }
    }
}