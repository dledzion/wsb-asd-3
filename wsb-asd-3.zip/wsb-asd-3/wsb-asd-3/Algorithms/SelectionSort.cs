﻿namespace wsb_asd_3.Algorithms
{
    public class SelectionSort : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            for (uint i = 0; i < (table.Length - 1); i++)
            {
                var temp = table[i];
                var k = i;
                for (var j = i + 1; j < table.Length; j++)
                {
                    if (table[j] < temp)
                    {
                        k = j;
                        temp = table[j];
                    }
                }

                table[k] = table[i];
                table[i] = temp;
            }
        }
    }
}