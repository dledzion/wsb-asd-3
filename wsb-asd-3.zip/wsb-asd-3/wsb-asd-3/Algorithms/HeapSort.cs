﻿namespace wsb_asd_3.Algorithms
{
    public class HeapSort : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            uint left = (uint)table.Length / 2;
            uint right = (uint)table.Length - 1;
            while (left > 0)
            {
                left--;
                Heapify(table, left, right);
            }
            while (right > 0)
            {
                var buf = table[left];
                table[left] = table[right];
                table[right] = buf;
                right--;
                Heapify(table, left, right);
            }
        }

        private void Heapify(int[] t, uint left, uint right)
        {
            uint i = left, j = 2 * i + 1;
            var buf = t[i];
            while (j <= right)
            {
                if (j < right)
                    if (t[j] < t[j + 1])
                        j++;
                if (buf >= t[j]) break;
                t[i] = t[j];
                i = j;
                j = 2 * i + 1;
            }
            t[i] = buf;
        }
    }
}