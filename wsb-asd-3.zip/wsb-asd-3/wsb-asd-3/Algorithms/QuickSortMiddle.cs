﻿namespace wsb_asd_3.Algorithms
{
    public class QuickSortMiddle : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            Sort(table, 0, table.Length - 1);
        }

        private void Sort(int[] table, int left, int right)
        {
            int i, j, x;
            i = left;
            j = right;
            x = table[(left + right) / 2];

            do
            {
                while (table[i] < x) i++;
                while (x < table[j]) j--;
                if (i <= j)
                {
                    int buf = table[i];
                    table[i] = table[j];
                    table[j] = buf;
                    i++;
                    j--;
                }
            } while (i <= j);

            if (left < j) Sort(table, left, j);
            if (i < right) Sort(table, i, right);
        }
    }
}