﻿namespace wsb_asd_3.Algorithms
{
    public class CocktailSort : ISortAlgorithm
    {
        public void Sort(int[] table)
        {
            var left = 1;
            var right = table.Length - 1;
            var k = table.Length - 1;

            do
            {
                for (var j = right; j >= left; j--)
                {
                    if (table[j - 1] > table[j])
                    {
                        var temp = table[j - 1];
                        table[j - 1] = table[j];
                        table[j] = temp;
                        k = j;
                    }
                }

                left = k + 1;

                for (var j = left; j <= right; j++)
                {
                    if (table[j - 1] > table[j])
                    {
                        var temp = table[j - 1];
                        table[j - 1] = table[j];
                        table[j] = temp;
                        k = j;
                    }
                }

                right = k - 1;
            } while (left <= right);
        }
    }
}